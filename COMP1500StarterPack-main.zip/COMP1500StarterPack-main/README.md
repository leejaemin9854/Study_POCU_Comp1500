# COMP1500StarterPack
Starter Pack for COMP 1500: Intro to Professional Programming
